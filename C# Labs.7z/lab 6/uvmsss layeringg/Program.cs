﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uvmsss_layeringg
{
    internal class Program
    {
        static void Main(string[] args)
        {

            string option;
            do
            {
                option = (uvmsUI.MainMenu());
                Console.Clear();
                if (option == "1") uvmsUI.AddStudent();
                else if (option == "2") uvmsUI.AddDegree();
                else if (option == "3") uvmsUI.GenerateMerit();
                else if (option == "4") uvmsUI.ViewRegisteredStudents();
                else if (option == "5") uvmsUI.ViewStudentsInDegree();
                else if (option == "6") uvmsUI.RegisterSubjects();
                else if (option == "7") uvmsUI.GenerateFees();
               

            } while (option != "8");
           
        }
    }
}
