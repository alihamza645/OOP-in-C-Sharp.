﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using uvmsss_layeringg;

namespace uvmsss_layeringg
{
    internal class uvmsUI
    {
        public static string MainMenu()
        {
                Console.Clear();
                Console.WriteLine("***********************************************************");
                Console.WriteLine("*              University Managment System                *");
                Console.WriteLine("***********************************************************");
                Console.WriteLine("1. Add Student");
                Console.WriteLine("2. Add Degree Program");
                Console.WriteLine("3. Generate Merit List");
                Console.WriteLine("4. View Registered Students");
                Console.WriteLine("5. View Students in Specific Degree");
                Console.WriteLine("6. Register Subjects");
                Console.WriteLine("7. Generate Fees");
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("8. Exit");
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("Select Option: ");
                string option = Console.ReadLine();
                
            
            return option ;
            }
        public static void AddStudent()
        {
            Console.Clear();
            Console.Write("Name = ");
            string name = Console.ReadLine();
            Console.Write("Age = ");
            int age = int.Parse(Console.ReadLine());
            Console.Write("FSC Marks = ");
            double fsc = double.Parse(Console.ReadLine());
            Console.Write("ECAT Marks = ");
            double ecat = double.Parse(Console.ReadLine());

            Console.WriteLine("Available Programs = ");
            int i = 0;
            while (i < uvmsDL.programList.Count)
            {
                Console.WriteLine("- " + uvmsDL.programList[i].title);
                i++;
            }

            List<DegreeProgram> prefs = new List<DegreeProgram>();
            Console.Write("Enter how many number of preferences = ");
            int count = int.Parse(Console.ReadLine());
            int j = 0;
            while (j < count)
            {
                Console.Write("Preference " + (j + 1) + ": ");
                string prefTitle = Console.ReadLine();
                int k = 0;
                while (k < uvmsDL.programList.Count)
                {
                    if (uvmsDL.programList[k].title == prefTitle)
                    {
                        prefs.Add(uvmsDL.programList[k]);
                        break;
                    }
                    k++;
                }
                j++;
            }

            Student s = new Student(name, age, fsc, ecat, prefs);
            uvmsDL.studentList.Add(s);
        }

        public static void AddDegree()
        {
            Console.Clear();
            Console.Write("Degree Title = ");
            string title = Console.ReadLine();
            Console.Write("Duration =  ");
            float duration = float.Parse(Console.ReadLine());
            Console.Write("Seats =  ");
            int seats = int.Parse(Console.ReadLine());

            DegreeProgram dp = new DegreeProgram(title, duration, seats);

            Console.Write("Enter How many Subjects to Enter =  ");
            int subCount = int.Parse(Console.ReadLine());
            int i = 0;
            while (i < subCount)
            {
                Console.Write("Enter Subject Code =  ");
                string code = Console.ReadLine();
                Console.Write("Enter Subject Name =  ");
                string type = Console.ReadLine();
                Console.Write("Enter Subject Credit Hours = ");
                int ch = int.Parse(Console.ReadLine());
                Console.Write("Enter Subject Fee =  ");
                int fee = int.Parse(Console.ReadLine());
                Console.WriteLine("Subject Added Successfully");
                Console.WriteLine("");

                Subject sub = new Subject(code, type, ch, fee);
                dp.AddSubject(sub);
                i++;
            }

            uvmsDL.programList.Add(dp);
        }

        public static void GenerateMerit()
        {
            
            foreach (Student s in uvmsDL.studentList)
            {
                s.calculateMerit();
            }

            
            uvmsDL.studentList.Sort(Student.CompareByMerit);

            
            foreach (Student s in uvmsDL.studentList)
            {
                foreach (DegreeProgram pref in s.preferences)
                {
                    foreach (DegreeProgram prog in uvmsDL.programList)
                    {
                        if (prog.title == pref.title && prog.seats > 0)
                        {
                            s.regDegree = prog;
                            prog.seats--;
                            break;
                        }
                    }

                    if (s.regDegree != null)
                        break;
                }
            }

            Console.WriteLine("Merit list generated and admissions assigned.");
            Console.ReadKey();
        }

        public static void ViewRegisteredStudents()
        {
            int i = 0;
            while (i < uvmsDL.studentList.Count)
            {
                Student s = uvmsDL.studentList[i];
                if (s.regDegree != null)
                    Console.WriteLine(s.name + " -> " + s.regDegree.title);
                i++;
            }
        }

        public static void ViewStudentsInDegree()
        {
            Console.Write("Enter Degree Title: ");
            string title = Console.ReadLine();
            int i = 0;
            while (i < uvmsDL.studentList.Count)
            {
                Student s = uvmsDL.studentList[i];
                if (s.regDegree != null && s.regDegree.title == title)
                    Console.WriteLine(s.name);
                i++;
            }
        }

        public static void RegisterSubjects()
        {
            Console.Write("Enter Student Name: ");
            string name = Console.ReadLine();

            int i = 0;
            while (i < uvmsDL.studentList.Count)
            {
                if (uvmsDL.studentList[i].name == name)
                {
                    Student s = uvmsDL.studentList[i];

                    if (s.regDegree != null)
                    {
                        s.viewSubjects();

                        Console.Write("Enter number of subjects to register: ");
                        int count = int.Parse(Console.ReadLine());

                        int j = 0;
                        while (j < count)
                        {
                            Console.Write("Enter Subject Code: ");
                            string code = Console.ReadLine();

                            bool found = false;
                            int k = 0;
                            while (k < s.regDegree.subjects.Count)
                            {
                                if (s.regDegree.subjects[k].code == code)
                                {
                                    found = true;
                                    bool success = s.regStudentSubject(s.regDegree.subjects[k]);

                                    if (success)
                                    {
                                        Console.WriteLine(" Subject registered.");
                                        Console.Read();
                                    }
                                    else
                                    {
                                        Console.WriteLine("Cannot register subject (Limit exceeded or invalid).");
                                    }
                                    break;
                                }
                                k++;
                            }

                            if (!found)
                            {
                                Console.WriteLine("Subject code not found in degree program.");
                            }

                            j++;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Student is not admitted to any degree.");
                    }

                    return;
                }
                i++;
            }

            Console.WriteLine("Student not found.");
        }

        public static void GenerateFees()
        {
            int i = 0;
            while (i < uvmsDL.studentList.Count)
            {
                Student s = uvmsDL.studentList[i];
                if (s.regDegree != null)
                {
                    float fee = s.calculateFee();
                    Console.WriteLine(s.name + " - Total Fee: Rs." + fee);
                    Console.Read();
                }
                i++;
            }
        }
    }
}

