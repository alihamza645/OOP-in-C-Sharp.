﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uvmsss_layeringg
{
    class Student
    {
        public string name;
        public int age;
        public double fscMarks;
        public double ecatMarks;
        public double merit;
        public List<DegreeProgram> preferences;
        public DegreeProgram regDegree;
        public List<Subject> regSubjects;

        public Student(string n, int a, double fsc, double ecat, List<DegreeProgram> prefs)
        {
            name = n;
            age = a;
            fscMarks = fsc;
            ecatMarks = ecat;
            preferences = prefs;
            regSubjects = new List<Subject>();
        }

        public void calculateMerit()
        {
            merit = (fscMarks / 1100) * 0.45 + (ecatMarks / 400) * 0.55;
        }

        public int getCreditHours()
        {
            int total = 0;
            int i = 0;
            while (i < regSubjects.Count)
            {
                total += regSubjects[i].creditHours;
                i++;
            }
            return total;
        }

        public float calculateFee()
        {
            float total = 0;
            int i = 0;
            while (i < regSubjects.Count)
            {
                total += regSubjects[i].subjectFee;
                i++;
            }
            return total;
        }

        public bool regStudentSubject(Subject s)
        {
            int stCH = getCreditHours();
            if (regDegree != null && regDegree.isSubjectExists(s) && stCH + s.creditHours <= 9)
            {
                regSubjects.Add(s);
                return true;
            }
            return false;
        }

        public void viewSubjects()
        {
            Console.WriteLine("Subjects for " + regDegree.title + ":");
            int i = 0;
            while (i < regDegree.subjects.Count)
            {
                Subject s = regDegree.subjects[i];
                Console.WriteLine(s.code + " - " + s.name + " - " + s.creditHours + " CH - Rs." + s.subjectFee);
                i++;
            }
        }
        public static int CompareByMerit(Student a, Student b)
        {
            return b.merit.CompareTo(a.merit); 
        }
    }

    class DegreeProgram
    {
        public string title;
        public float duration;
        public int seats;
        public List<Subject> subjects;

        public DegreeProgram(string t, float d, int s)
        {
            title = t;
            duration = d;
            seats = s;
            subjects = new List<Subject>();
        }

        public bool isSubjectExists(Subject sub)
        {
            int i = 0;
            while (i < subjects.Count)
            {
                if (subjects[i].code == sub.code)
                    return true;
                i++;
            }
            return false;
        }

        public void AddSubject(Subject s)
        {
            int totalCH = calculateCreditHours();
            if (totalCH + s.creditHours <= 20)
            {
                subjects.Add(s);
            }
            else
            {
                Console.WriteLine("Cannot add subject. Credit hour limit exceeded.");
            }
        }

        public int calculateCreditHours()
        {
            int total = 0;
            int i = 0;
            while (i < subjects.Count)
            {
                total += subjects[i].creditHours;
                i++;
            }
            return total;
        }
    }

    class Subject
    {
        public string code;
        public string name;
        public int creditHours;
        public int subjectFee;

        public Subject(string c, string t, int ch, int fee)
        {
            code = c;
            name = t;
            creditHours = ch;
            subjectFee = fee;
        }
    
    }
    internal class uvmsBL
    {

    }
}

