﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uvmsss_layeringg
{
    internal class uvmsDL
    {
        public static List<Student> studentList = new List<Student>();
        public static List<DegreeProgram> programList = new List<DegreeProgram>();
          
    }
}
