﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace lab_7
{
     
    public class book
    {
        public string title;
        public book(string title)
        {
            this.title = title;
        }
        public void showbook()
        {
            Console.WriteLine("Book name: " + title);
        }

    }
    public class author
    {
        public string name;
        public List<book> books;
        public author(string name, List<book> books)
        {
            this.name = name;
            this.books = books;
        }
        public void showbookinfo()
        {
            Console.WriteLine("Author name: " + name);
            foreach (var book in books)
            {
                book.showbook();
            }
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            book b1 = new book("OOP");
            List<book> books = new List<book>();
            books.Add(b1);
            author a1 = new author("Rimsha Afzal", books);
            Console.WriteLine("Book info: ");
            a1.showbookinfo();
            a1 = null;
            Console.WriteLine("Author removed but book still exist!");
            b1.showbook();
        }
    }
}



/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace lab_7
{

    public class song
    {
        public string name;
        public string artist;
        public song(string name, string artist)
        {
            this.name = name;
            this.artist = artist;
        }
        public void showsongs()
        {
            Console.WriteLine("Song: " + " " + "Artist: " + artist);
        }
    }
    public class playlist
    {
        public string name;
        public List<song> songs;
        public playlist(string name, List<song> songs)
        {
            this.name = name;
            this.songs = songs;
        }
        public void showplaylist()
        {
            Console.WriteLine("Playlist: " + name);
            Console.WriteLine("Songs: ");
            foreach (var song in songs)
            {
                song.showsongs();
            }
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            song s1 = new song("804", "sidhu");
            List<song> songs = new List<song>();
            songs.Add(s1);
            playlist p1 = new playlist("imran khan ", songs);
            p1.showplaylist();
            p1 = null;
            Console.WriteLine("playlist removed but songs still exist!");
            s1.showsongs();
        }
    }
}*/

/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace lab_7
{
    public class workout
    {
        public string name;
        public string exercise;
        public List<Exercise> exercises;
        public workout(string name)
        {
            this.name = name;
            exercises = new List<Exercise>();
        }
        public void addexercise(string exercise)
        {
            Exercise e1 = new Exercise(exercise);
            exercises.Add(e1);
        }
        public void showinfo()
        {
            Console.WriteLine("Workout: " + name);
            foreach (var e in exercises)
            {
                e.showexercise();
            }
        }
    }
    public class Exercise
    {
        public string name;
        public List<Set> sets = new List<Set>();
        public Exercise(string name)
        {
            this.name = name;
        }
        public Exercise(string name, List<Set> sets)
        {
            this.name = name;
            this.sets = sets;
        }
        public void showexercise()
        {
            Console.WriteLine("Exercise: " + name);
        }
        public void displayexercise()
        {
            Console.WriteLine("Exercise: " + name);
            foreach (var c in sets)
            {
                c.showsets();
            }
        }
    }
    public class Set
    {
        public int number;
        public Set(int number)
        {
            this.number = number;
        }
        public void showsets()
        {
            Console.WriteLine("Sets: " + number);
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            workout w1 = new workout("lifting");
            w1.addexercise("Chinups");
            w1.showinfo();
            w1 = null;
            Console.WriteLine("Workout removed exercises also removed!");
            List<Set> sets = new List<Set>();
            Exercise e1 = new Exercise("Deadlifting", sets);
            Set s1 = new Set(5);
            sets.Add(s1);
            e1.displayexercise();
            e1 = null;
            Console.WriteLine("Exercise removed but sets still exist!");
            s1.showsets();
        }
    }
}*/



/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace lab_7
{
    public class User
    {
        public string name;
        public List<User> followers = new List<User>();
        public List<User> following = new List<User>();
        public User(string name)
        {
            this.name = name;
        }

        public void Follow(User user)
        {
            if (user != this && !following.Contains(user))
            {
                following.Add(user);
                user.followers.Add(this);
            }
        }

        public void ShowFollowers()
        {
            foreach (var f in followers)
            {
                Console.WriteLine(f.name + " " + "Follows: " + name);
            }
        }

        public void ShowFollowing()
        {
            Console.WriteLine("Following: ");
            foreach (var f in following)
            {
                Console.WriteLine(f.name);
            }
        }
    }
    public class Post
    {
        public string name;
        public string content;
        public int like;
        public List<Like> likes;
        public List<Comment> comments;
        public Post(string name)
        {
            this.name = name;
            likes = new List<Like>();
            comments = new List<Comment>();
        }
        public void addcomments(string content)
        {
            Comment c1 = new Comment(content);
            comments.Add(c1);
        }
        public void addlikes(int Likes)
        {
            Like l1 = new Like(Likes);
            likes.Add(l1);
        }
        public void showpost()
        {
            Console.WriteLine("Post name: " + name);
            Console.WriteLine("***Comments*** ");
            foreach (var c in comments)
            {
                c.showcomment();
            }
            Console.WriteLine("***Likes*** ");
            foreach (var l in likes)
            {
                l.showlike();
            }
        }
    }
    public class Comment
    {
        public string content;
        public Comment(string content)
        {
            this.content = content;
        }
        public void showcomment()
        {
            Console.WriteLine("Comment: " + content);
        }
    }
    public class Like
    {
        public int like;
        public Like(int like)
        {
            this.like = like;
        }
        public void showlike()
        {
            Console.WriteLine("Like: " + like);
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            User u1 = new User("bob");
            User u2 = new User("john");
            User u3 = new User("Alice");
            u1.Follow(u2);
            u2.Follow(u3);
            u1.ShowFollowers();
            u2.ShowFollowers();
            u2.followers.Remove(u1);
            Console.WriteLine("Follower removed but the user still exist!");
            Console.WriteLine(u1.name);
            Post p1 = new Post("bytecamp");
            p1.addcomments("Thats great!");
            p1.addlikes(2);
            p1.showpost();
            p1 = null;
            Console.WriteLine("Post removed and comments and likes are also removed!");
        }
    }
}*/

/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace lab_7
{
    public class Rectangle
    {
        private double width;
        private double height;
        public double Width
        {
            get { return width; }
            set { width = value; }
        }

        public double Height
        {
            get { return height; }
            set { height = value; }
        }

        public Rectangle()
        {
            Width = 1.0;
            Height = 1.0;
        }

        public Rectangle(double w, double h)
        {
            Width = w;
            Height = h;
        }
        public void SetDimensions(double w, double h)
        {
            Width = w;
            Height = h;
        }

        public double GetArea()
        {
            return Width * Height;
        }

        public double GetPerimeter()
        {
            return 2 * (Width + Height);
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Rectangle rect1 = new Rectangle();
            Console.WriteLine("***DefaultConstrucotr ***");
            Console.WriteLine($"Initial Dimensions: {rect1.Width} x {rect1.Height}");
            Console.WriteLine($"Area: {rect1.GetArea()}");
            Console.WriteLine($"Perimeter: {rect1.GetPerimeter()}");
            rect1.SetDimensions(5.0, 10.0);
            Console.WriteLine("***After SettingDimensions***");
            Console.WriteLine($"New Dimensions: {rect1.Width} x {rect1.Height}");
            Console.WriteLine($"Area: {rect1.GetArea()}");
            Console.WriteLine($"Perimeter: {rect1.GetPerimeter()}");
            Rectangle rect2 = new Rectangle(2.5, 7.0);
            Console.WriteLine("***ParameterizedConstructor***");
            Console.WriteLine($"Initial Dimensions: {rect2.Width} x {rect2.Height}");
            Console.WriteLine($"Area: {rect2.GetArea()}");
            Console.WriteLine($"Perimeter: {rect2.GetPerimeter()}");
        }
    }
}*/



/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace lab_7
{
    public class Student
    {
        private string name;
        private int rollNo;
        private double marks;
        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }
        public int RollNo
        {
            get { return this.rollNo; }
            set { this.rollNo = value; }
        }
        public double Marks
        {
            get { return this.marks; }
            set { this.marks = value; }
        }
        public Student()
        {

        }
        public Student(string name, int rollNo)
        {
            this.name = name;
            this.rollNo = rollNo;
            marks = 0.0;
        }
        public void PrintDetails()
        {
            Console.WriteLine($"Student Name: {Name}");
            Console.WriteLine($"Roll Number: {RollNo}");
            Console.WriteLine($"Marks: {Marks}");
            if (IsPass())
            {
                Console.WriteLine("Passing Status: Passed");
            }
            else
            {
                Console.WriteLine("Passing Status: Failed");
            }
        }
        public bool IsPass()
        {
            return Marks >= 50;
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Student s1 = new Student("Alice", 121);
            s1.Marks = 90.0;
            Console.WriteLine("Student 1 details: ");
            s1.PrintDetails();
            Student s2 = new Student();
            s2.Name = "John";
            s2.RollNo = 156;
            s2.Marks = 49.0;
            Console.WriteLine("Student 2 details: ");
            s2.PrintDetails();
        }
    }
}*/