﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace polymorlab
{
    internal class Program
    {
        public class Circle
        {
            protected double radius;
            protected string color;

         
            public Circle()
            {
                radius = 1.0;
                color = "red";
            }

         
            public Circle(double radius)
            {
                this.radius = radius;
                color = "red";
            }

         
            public Circle(double radius, string color)
            {
                this.radius = radius;
                this.color = color;
            }

        
            public double GetRadius()
            {
                return radius;
            }

            public void SetRadius(double radius)
            {
                this.radius = radius;
            }

            public string GetColor()
            {
                return color;
            }

            public void SetColor(string color)
            {
                this.color = color;
            }

        
            public double GetArea()
            {
                return Math.PI * radius * radius;
            }

       
            public override string ToString()
            {
                return $"Circle[radius={radius},color={color}]";
            }
        }

        public class Cylinder : Circle
        {
            private double height;

        
            public Cylinder() : base()
            {
                height = 1.0;
            }

            
            public Cylinder(double radius) : base(radius)
            {
                height = 1.0;
            }

        
            public Cylinder(double radius, double height) : base(radius)
            {
                this.height = height;
            }

           
            public Cylinder(double radius, double height, string color) : base(radius, color)
            {
                this.height = height;
            }

        
            public double GetHeight()
            {
                return height;
            }

            public void SetHeight(double height)
            {
                this.height = height;
            }

            
            public double GetVolume()
            {
                return GetArea() * height;
            }

           
            public override string ToString()
            {
                return $"Cylinder: subclass of {base.ToString()} height={height}";
            }
        }


 
            static void Main(string[] args)
            {
               
                Cylinder c1 = new Cylinder();
                Cylinder c2 = new Cylinder(2.5);
                Cylinder c3 = new Cylinder(2.5, 5.0);
                Cylinder c4 = new Cylinder(2.5, 5.0, "blue");

                Console.WriteLine(c1.ToString());
                Console.WriteLine($"Volume: {c1.GetVolume()}");

                Console.WriteLine(c2.ToString());
                Console.WriteLine($"Volume: {c2.GetVolume()}");

                Console.WriteLine(c3.ToString());
                Console.WriteLine($"Volume: {c3.GetVolume()}");

                Console.WriteLine(c4.ToString());
                Console.WriteLine($"Volume: {c4.GetVolume()}");
            }
        }
    }*/




/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace polymorlab
{
    internal class Program
    {
        public class Person
        {
            protected string name;
            protected string address;

            public Person(string name, string address)
            {
                this.name = name;
                this.address = address;
            }

            public string GetName()
            {
                return name;
            }

            public string GetAddress()
            {
                return address;
            }

            public void SetAddress(string address)
            {
                this.address = address;
            }

            public override string ToString()
            {
                return $"Person[name={name}, address={address}]";
            }
        }



        public class Student : Person
        {
            private string program;
            private int year;
            private double fee;

            public Student(string name, string address, string program, int year, double fee)
                : base(name, address)
            {
                this.program = program;
                this.year = year;
                this.fee = fee;
            }

            public string GetProgram()
            {
                return program;
            }

            public void SetProgram(string program)
            {
                this.program = program;
            }

            public int GetYear()
            {
                return year;
            }

            public void SetYear(int year)
            {
                this.year = year;
            }

            public double GetFee()
            {
                return fee;
            }

            public void SetFee(double fee)
            {
                this.fee = fee;
            }

            public override string ToString()
            {
                return $"Student[{base.ToString()}, program={program}, year={year}, fee={fee}]";
            }
        }



        public class Staff : Person
        {
            private string school;
            private double pay;

            public Staff(string name, string address, string school, double pay)
                : base(name, address)
            {
                this.school = school;
                this.pay = pay;
            }

            public string GetSchool()
            {
                return school;
            }

            public void SetSchool(string school)
            {
                this.school = school;
            }

            public double GetPay()
            {
                return pay;
            }

            public void SetPay(double pay)
            {
                this.pay = pay;
            }

            public override string ToString()
            {
                return $"Staff[{base.ToString()}, school={school}, pay={pay}]";
            }
        }





        static void Main(string[] args)
           
    {
        Student s1 = new Student("Ali", "Lahore", "Computer Science", 2025, 150000);
        Student s2 = new Student("Sara", "Karachi", "Business", 2024, 130000);

        Staff st1 = new Staff("Mr. Khan", "Islamabad", "Beaconhouse", 80000);
        Staff st2 = new Staff("Ms. Fatima", "Multan", "Roots International", 85000);

        Console.WriteLine(s1.ToString());
        Console.WriteLine(s2.ToString());
        Console.WriteLine(st1.ToString());
        Console.WriteLine(st2.ToString());
    }

          
            }
}*/


namespace polymorlab
{
    internal class Program
    {
        public class Person
        {
  
        }
        static void Main(string[] args)

        {
            
        }


    }
}
