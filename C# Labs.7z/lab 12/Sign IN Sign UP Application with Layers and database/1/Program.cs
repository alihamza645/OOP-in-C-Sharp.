﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1
{
    class MUser
    {
        public string name;
        public string password;
        public string role;

        public MUser(string name, string password)
        {
            this.name = name;
            this.password = password;
        }

        public MUser(string name, string password, string role)
        {
            this.name = name;
            this.password = password;
            this.role = role;
        }

        public string getUserName()
        {
            return name;
        }
        public string getUserPassword()
        {
            return password;
        }

        public string getUserRole()
        {
            return role;
        }


        public bool isAdmin()
        {
            return role == "Admin"|| role=="admin"|| role=="ADMIN";
        }
}





    class MUserCRUD
    {
        static string connStr = "Server=LENOVOTHINKBOOK;Database=BusinessApp;Trusted_Connection=True;"; 


        public static List<MUser> users = new List<MUser>();

        public static void addUserIntoList(MUser user)
        {
            users.Add(user);
        }

        public static MUser SignIn(MUser user)
        {
            foreach (MUser storedUser in users)
            {
                if (user.getUserName() == storedUser.getUserName() &&
                    user.getUserPassword() == storedUser.getUserPassword())
                    return storedUser;
            }
            return null;
        }



        public static void storeDataInList(MUser user)
        {
            users.Add(user);
        }


        public static void ReadDataFromDatabase()
        {
            // Clear the list so no old or duplicate data remains in memory 
            users.Clear();

            // Create a SQL connection object using the connection string 
            using (SqlConnection conn = new SqlConnection(connStr))

            // Create a SQL command object with a SELECT query and the connection 
            using (SqlCommand cmd = new SqlCommand(
                "SELECT Username, Password, Role FROM dbo.Users", conn))
            {
                // Open the connection to the database 
                conn.Open();

                // Execute the SELECT query and get a SqlDataReader to read rows 
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    // Loop through each row returned by the database 
                    while (reader.Read())
                    {
                        // Read column 0 (Username) as a string 
                        string name = reader.GetString(0);

                        // Read column 1 (Password) as a string 
                        string pass = reader.GetString(1);

                        // Read column 2 (Role) as a string 
                        string role = reader.GetString(2);

                        // Create a new MUser object using the data from this row 
                        // and add it to the in-memory list 
                        users.Add(new MUser(name, pass, role));
                    }
                }
            }
        }
        public static bool AddUserToDatabase(MUser user)
        {
            // Create a new SQL connection object using the connection string 
            using (SqlConnection conn = new SqlConnection(connStr))

            // Create a SQL command to insert a new user into the Users table 
            using (SqlCommand cmd = new SqlCommand(
                 "INSERT INTO dbo.Users (Username, Password, Role, CreatedAt) VALUES (@u, @p, @r, @c)", conn))
            {
                // Add parameter @u and set its value to the user's username 
                cmd.Parameters.Add("@u", SqlDbType.NVarChar, 100).Value = user.getUserName();

                // Add parameter @p and set its value to the user's password 
                cmd.Parameters.Add("@p", SqlDbType.NVarChar, 256).Value = user.getUserPassword();

                // Add parameter @r and set its value to the user role (Admin/User) 
                cmd.Parameters.Add("@r", SqlDbType.NVarChar, 50).Value = user.getUserRole();

                // Add parameter @c and set the current date/time for record creation 
                cmd.Parameters.Add("@c", SqlDbType.DateTime).Value = DateTime.Now;

                // Open the SQL connection so we can communicate with the database 
                conn.Open();

                try
                {
                    // Execute the INSERT command in the database 
                    cmd.ExecuteNonQuery();

                    // Also add the user to the in-memory list (so the app can use it immediately) 
                    users.Add(user);

                    // Return true to show that the user was successfully inserted 
                    return true;
                }
                catch (SqlException ex)
                {
                    // Error numbers 2627 and 2601 mean: "Duplicate username" 
                    if (ex.Number == 2627 || ex.Number == 2601)
                        return false;  // username already exists, cannot add this user 

                    else
                        throw; // If it's any other SQL error, rethrow it for debugging 
                }
            }
        }
        public static MUser signIn(MUser user)
        {
            foreach (MUser storeUser in MUserCRUD.users)
            {
                if (user.name == storeUser.name && user.password == storeUser.password)
                {
                    return storeUser;
                }
            }
            return null;
        }
    }





    class MUSERUI
    {
        public static int menu()
        {
            int option;
            Console.WriteLine("1. SignIn");
            Console.WriteLine("2. SignUp");
            Console.Write("Enter Option = ");
            option = int.Parse(Console.ReadLine());
            return option;
        }

        public static MUser takeInputWithoutRole()
        {
            Console.Write("Enter Name = ");
            string name = Console.ReadLine();
            Console.Write("Enter Password = ");
            string password = Console.ReadLine();
            if (name != null && password != null)
            {
                return new MUser(name, password);
            }
            return null;
        }


        public static MUser takeInputWithRole()
        {
            Console.Write("Enter Name = ");
            string name = Console.ReadLine();
            Console.Write("Enter Password = ");
            string password = Console.ReadLine();
            Console.Write("Enter Role = ");
            string role = Console.ReadLine();
            if (name != null && password != null && role != null)
            {
                return new MUser(name, password, role);
            }
            return null;
        }
    }

    internal class Program
    {
       
        static void Main(string[] args)
        {
            MUserCRUD.ReadDataFromDatabase();
          
       
            int option;

            do
            {
                Console.Clear();
                option = MUSERUI.menu();
                Console.Clear();

                if (option == 1)
                {
                    MUser user = MUSERUI.takeInputWithoutRole();
                    if (user != null)
                    {
                        user = MUserCRUD.signIn(user);
                        if (user == null)
                            Console.WriteLine("Invalid User");
                        else if (user.isAdmin())
                            Console.WriteLine("Admin Menu");
                        else
                            Console.WriteLine("User Menu");
                    }
                }
                else if (option == 2)
                {

                    MUser user = MUSERUI.takeInputWithRole();
                    if (user != null)
                    {
                        bool inserted = MUserCRUD.AddUserToDatabase(user);
                      
                    }
                }

                Console.ReadKey();
            }
            while (option < 3);
        }
    }
}











