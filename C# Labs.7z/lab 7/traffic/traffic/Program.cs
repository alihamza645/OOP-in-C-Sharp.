﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Collections.Specialized.BitVector32;

namespace traffic
{
    public class car
    {
        public string carname;
        public car(string name)
        {
            this.carname = name;
        }
        public void onsignalchange(string action)
        {
            Console.WriteLine($"I am {carname} and I am in {action} state");
        }
    }
    public class trafficsignal
    {
        public string state;
        public List<car> carlist = new List<car>();
        public void addcar(car c)
        {
            carlist.Add(c);
        }
        public void setred()
        {
            state = "Red";
            informcars();
        }
        public void setgreen()
        {
            state = "Green";
            informcars();
        }
     
        public void informcars()
        {
            foreach (car car in carlist)
            {
                car.onsignalchange(state);
            }
        }
        internal class Program
        {
            static void Main(string[] args)
            {
                car car1 = new car("Car 1");
                car car2 = new car("Car 2");
                trafficsignal signal1 = new trafficsignal();
                signal1.addcar(car1);
                signal1.addcar(car2);
                signal1.setred();
                signal1.setgreen();
                signal1 = null;
                Console.WriteLine("Trafficsignal object deleted");
                car1.onsignalchange("Red");
                Console.WriteLine("Car still exist");
            }
        }
    }
}*/




/*using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Collections.Specialized.BitVector32;
using System.Collections.Generic;

namespace traffic
{
    public class TableOfContents
    {
        public List<string> items;

        public TableOfContents()
        {
            items = new List<string>();
            Console.WriteLine("TableOfContents created.");
        }

        public void AddItem(string item)
        {
            items.Add(item);
        }

        public void Print()
        {
            Console.WriteLine("Table of Contents:");
            foreach (string item in items)
            {
                Console.WriteLine($"- {item}");
            }
        }
    }
    public class Book
    {
        public TableOfContents toc;

        public Book()
        {
            toc = new TableOfContents(); 
            Console.WriteLine("Book created.");
        }

        public void AddContent(string item)
        {
            toc.AddItem(item);
        }

        public void PrintContent()
        {
            toc.Print();
        }

     
    }

  internal class Program
    {
        static void Main(string[] args)
        {
            Book myBook = new Book(); 
            myBook.AddContent("Chapter 1: Introduction");
            myBook.AddContent("Chapter 2: Basics");

            Console.WriteLine("\n--- Book Contents ---");
            myBook.PrintContent();

            myBook = null; 
            Console.WriteLine("Book object deleted.");
           
            


        }
    }
}*/




/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Collections.Specialized.BitVector32;

namespace traffic
{
    public class Football
    {
        public string Type;
        public int Size;
        public float Weight;
        public Football()
        {
            Type = "Standard";
            Size = 5;
            Weight = 0.45f;
        }
        public Football(string type, int size, float weight)
        {
            Type = type;
            Size = size;
            Weight = weight;
        }
        public void ShowFootballInfo()
        {
            Console.WriteLine($"Football Type: {Type}, Size: {Size}, Weight: {Weight} kg");
        }

        public class FootballPlayer
        {
            public string Name;
            public Football ball;   
            public FootballPlayer()
            {
                Name = "Unknown Player";
                ball = null; 
            }

            public FootballPlayer(string name, Football f)
            {
                Name = name;
                ball = f;   
            }
            public void ShowPlayerInfo()
            {
                Console.WriteLine($"Player Name: {Name}");
                if (ball != null)
                    ball.ShowFootballInfo();
                else
                    Console.WriteLine("No football assigned.");
            }
        }

    }


    internal class Program
        {
            static void Main(string[] args)
            {
            Football f1 = new Football("Leather", 5, 0.43f);
            FootballPlayer p1 = new FootballPlayer("Cristiano", f1);
            p1.ShowPlayerInfo();
            p1 = null;
            Console.WriteLine("Player deleted.");
            f1.ShowFootballInfo();
            Console.ReadKey();
        }
    }
    }*/







using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
public class Author
{
    public string Name;
    public string Email;
    public string Gender;

    public Author()
    {
        Name = "Unknown";
        Email = "unknown@example.com";
        Gender = "Unspecified";
    }

    public Author(string name, string email, string gender)
    {
        Name = name;
        Email = email;
        Gender = gender;
    }

    public void ShowAuthorInfo()
    {
        Console.WriteLine($"Author Name: {Name}, Email: {Email}, Gender: {Gender}");
    }
}

public class Book
{
    public string Title;
    public Author Writer;
    public double Price;
    public int Quantity;

    public Book()
    {
        Title = "Untitled";
        Writer = null;
        Price = 0.0;
        Quantity = 0;
    }

    public Book(string title, Author author, double price, int quantity)
    {
        Title = title;
        Writer = author;
        Price = price;
        Quantity = quantity;
    }

    public void ShowBookInfo()
    {
        Console.WriteLine($"Book Title: {Title}, Price: ${Price}, Quantity: {Quantity}");
        if (Writer != null)
            Writer.ShowAuthorInfo();
        else
            Console.WriteLine("No author assigned.");
    }
}

internal class Program
{
    static void Main(string[] args)
    {
        Author a1 = new Author("Hamza", "hamza@example.com", "Male");
        Book b1 = new Book("C#", a1, 1000, 10);

        b1.ShowBookInfo();
        b1 = null;
        Console.WriteLine("Book deleted.");

        a1.ShowAuthorInfo();
        Console.ReadKey();
    }
}






/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
public class course
{
    public string coursename;
    public double credithours;

    public course()
    {
        coursename = "unknown";
        credithours = 0;
    }

    public course(string coursename, double credithours)
    {
        this.coursename = coursename;
        this.credithours = credithours;
    }

    public void Showcourse()
    {
        Console.WriteLine($"Course Name: {coursename}, Credit Hours: {credithours}");
    }
}

public class teacher
{
    public string teachername;
    public course hours;

    public teacher()
    {
       teachername = "unknown";
        hours = null;
    }

    public teacher(string teachername, course hours)
    {
       this.teachername = teachername;
        this.hours = hours; 
    }

    public void Showteacher()
    {
        Console.WriteLine($"Teacher Name: {teachername}, Course: {hours}");
        if (hours != null)
            hours.Showcourse();
        else
            Console.WriteLine("No course assigned.");
    }
}

internal class Program
{
    static void Main(string[] args)
    {
        course a1 = new course("OOP",3);
        teacher b1 = new teacher("Sir Hamza",a1);

        b1.Showteacher();
        b1 = null;
        Console.WriteLine("teacher object deleted.");

        a1.Showcourse();
        Console.ReadKey();
    }
}*/




/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Patient
{
    public string Name;
    public int Age;

    public Patient(string name, int age)
    {
        Name = name;
        Age = age;
    }

    public void ShowPatientInfo()
    {
        Console.WriteLine($"Patient Name: {Name}, Age: {Age}");
    }
}

public class Doctor
{
    public string Name;
    public string Specialization;
    public List<Patient> Patients;

    public Doctor(string name, string specialization)
    {
        Name = name;
        Specialization = specialization;
        Patients = new List<Patient>();
    }

    public void AddPatient(Patient p)
    {
        Patients.Add(p);
    }

    public void ShowDoctorInfo()
    {
        Console.WriteLine($"Doctor Name: {Name}, Specialization: {Specialization}");
        Console.WriteLine("Patients under care:");
        foreach (Patient p in Patients)
        {
            p.ShowPatientInfo();
        }
    }
}

internal class Program
{
    static void Main(string[] args)
    {
        
        Patient p1 = new Patient("Ali", 30);
        Patient p2 = new Patient("Sara", 25);
        Patient p3 = new Patient("Zain", 20);

        Doctor d1 = new Doctor("Dr.Hamza", "Cardiology");
        d1.AddPatient(p1);
        d1.AddPatient(p2);
        d1.AddPatient(p3);
        
        d1.ShowDoctorInfo();
   
        d1 = null;
        Console.WriteLine("Doctor reference removed.");

        
        p1.ShowPatientInfo();
        p2.ShowPatientInfo();
        p3.ShowPatientInfo();
        Console.WriteLine("Patient still exist");
        Console.ReadKey();
    }
}*/





/*using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace traffic
{
    public class Book
    {
        public string Title;
        public string Author;
        public Book(string title, string author)
        {
            Title = title;
            Author = author;
        }
        public void ShowInfo()
        {
            Console.WriteLine($"Title: {Title}, Author: {Author}");
        }
    }
    public class Library
    {
        public List<Book> books;
        public Library()
        {
            books = new List<Book>();
        }
        public void AddBook(Book b)
        {
            books.Add(b);
        }

        public void ShowBooks()
        {
            Console.WriteLine("Library contains:");
            foreach (Book b in books)
            {
                b.ShowInfo();
            }
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            Book b1 = new Book("1984", "George Orwell");
            Book b2 = new Book("Brave New World", "Aldous Huxley");

            Library myLibrary = new Library();
            myLibrary.AddBook(b1);
            myLibrary.AddBook(b2);
            myLibrary.ShowBooks();
            myLibrary = null;

            Console.WriteLine("Library Deleted");
            b1.ShowInfo();
            b2.ShowInfo();
            Console.WriteLine("Books still present");
        }
    }
}*/




/*using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
namespace traffic
{
    public class Car
    {
        public string Model;
        public string Number;

        public Car(string model, string number)
        {
            Model = model;
            Number = number;
        }

        public void ShowCar()
        {
            Console.WriteLine($"Car Model: {Model}, Number: {Number}");
        }
    }
    public class Driver
    {
        public string Name;
        public Car AssignedCar;
        public Driver(string name, Car car)
        {
            Name = name;
            AssignedCar = car;
        }

        public void ShowDriver()
        {
            Console.WriteLine($"Driver Name: {Name}");
            Console.Write("Driving: ");
            AssignedCar.ShowCar();
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Car car1 = new Car("Civic", "ABC-295");

            Driver d1 = new Driver("Ali", car1);
            d1.ShowDriver();
            d1 = null;
            Console.WriteLine("Driver resigned.");
            car1.ShowCar();
            Console.WriteLine("Car still exist");
        }
    }
}*/


//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------




