﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_8
{


    public class Bike
    {
        protected int speed { get; set; }
        protected int gear { get; set; }

        public Bike(int speed, int gear)
        {
            this.speed = speed;
            this.gear = gear;
        }

        public void ApplyBrake(int decrease)
        {
            speed = speed - decrease;
            if (speed < 0)
                speed = 0;
        }

        public void SpeedUp(int increase)
        {
            speed = speed + increase;
        }

        public virtual void Display()
        {
            Console.WriteLine("Speed: " + speed);
            Console.WriteLine("Gear: " + gear);
        }
    }

    public class MountainBike : Bike
    {
        protected int seatHeight { get; set; }

        public MountainBike(int speed, int gear, int seatHeight)
            : base(speed, gear)
        {
            this.seatHeight = seatHeight;
        }

        public void SetHeight(int height)
        {
            seatHeight = height;
        }

        public override void Display()
        {
            base.Display();
            Console.WriteLine("Seat Height: " + seatHeight);
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            MountainBike mb = new MountainBike(20, 3, 5);
            mb.SpeedUp(10);
            mb.ApplyBrake(3);
            mb.SetHeight(12);
            mb.Display();
        }
    }
}*/



/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_8
{

    public class Circle
    {
        protected double radius { get; set; }

        public Circle(double radius)
        {
            this.radius = radius;
        }

        public virtual double Area()
        {
            return Math.PI * radius * radius;
        }

        public virtual void Display()
        {
            Console.WriteLine("Radius: " + radius);
            Console.WriteLine("Area: " + Area());
        }
    }

    public class Cylinder : Circle
    {
        protected double height { get; set; }

        public Cylinder(double radius, double height)
            : base(radius)
        {
            this.height = height;
        }

        public double Volume()
        {
            return Area() * height;
        }

        public override void Display()
        {
            base.Display();
            Console.WriteLine("Height: " + height);
            Console.WriteLine("Volume: " + Volume());
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Cylinder c = new Cylinder(5, 10);
            c.Display();
        }
    }
}*/




/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_8
{
    public class Account
    {
        protected string title { get; set; }
        protected string number { get; set; }
        protected double balance { get; set; }

        public Account(string title, string number, double balance)
        {
            this.title = title;
            this.number = number;
            this.balance = balance;
        }

        public virtual void Credit(double amount)
        {
            balance = balance + amount;
            Console.WriteLine(amount + " credited. New balance: " + balance);
        }

        public virtual void Debit(double amount)
        {
            if (amount <= balance)
           {
                balance = balance - amount;
                Console.WriteLine(amount + " debited. New balance: " + balance);
            }
            else
            {
                Console.WriteLine("Insufficient balance!");
            }
        }

        public virtual void Display()
        {
            Console.WriteLine("Title: " + title);
            Console.WriteLine("Number: " + number);
            Console.WriteLine("Balance: " + balance);
        }
    }

    public class StudentAccount : Account
    {
        protected double creditLimit { get; set; }

        public StudentAccount(string title, string number, double balance)
            : base(title, number, balance)
        {
            creditLimit = 500000;
        }

        public override void Debit(double amount)
        {
            if (balance + creditLimit >= amount)
            {
                balance = balance - amount;
                Console.WriteLine("Student A/C debited by " + amount + ". New balance: " + balance);
            }
            else
            {
                Console.WriteLine("Credit limit exceeded!");
            }
        }

        public override void Display()
        {
            base.Display();
            Console.WriteLine("Credit Limit: " + creditLimit);
        }
    }

    public class SalaryAccount : Account
    {
        public SalaryAccount(string title, string number, double balance)
            : base(title, number, balance)
        {
        }

        public override void Debit(double amount)
        {
            if (amount <= balance)
            {
                balance = balance - amount;
                Console.WriteLine("Salary A/C debited by " + amount + ". New balance: " + balance);
            }
            else
            {
                Console.WriteLine("Salary account cannot be negative!");
            }
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            StudentAccount sa = new StudentAccount("bial", "ST-001", 99000);
            SalaryAccount sal = new SalaryAccount("bilal Salary", "EMP-001", 9000);

            Console.WriteLine("*** STUDENT ACCOUNT ***");
            sa.Credit(5000);
            sa.Debit(200000);
            sa.Display();

            Console.WriteLine("***SALARY ACCOUNT***");
            sal.Credit(3000);
            sal.Debit(60000);
            sal.Display();
        }
    }
}*/