﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Hello World ");
            Console.Write("Hello World");
            Console.ReadKey();
        }
    }
}*/



/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World ");
            Console.Write("Hello World");
            Console.ReadKey();
        }
    }
}*/


/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter length of square = ");
            float length = float.Parse(Console.ReadLine());
            Console.Write("Enter width of square = ");
            float width = float.Parse(Console.ReadLine());
            float area = length * width;
            Console.Write("Area of the square = "+area);
            Console.ReadKey();
        }
    }
}*/


/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your marks = ");
            float marks = float.Parse(Console.ReadLine());
            if (marks > 50)
            {
                Console.WriteLine("You are Passed");
            }
            else
            {
                Console.WriteLine("You are Failed");
            }
            Console.ReadKey();
        }
    }
}*/


/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            for(int i = 0; i < 5; i++)
            {
                Console.WriteLine("Welcome Jack");
            }
            Console.ReadKey();
        }
    }
}*/




/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int sum = 0;
            Console.Write("Enter a number = ");
            int num = int.Parse(Console.ReadLine());
            while(num != -1)
            {
                 sum = sum + num;
                Console.Write("Enter a number = ");
                num = int.Parse(Console.ReadLine());
            }
            Console.WriteLine("The total sum = "+sum);
            Console.ReadKey();

        }
    }
}*/


/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num;
            int sum = 0;
            do
            {
                Console.Write("Enter a number = ");
                num=int.Parse(Console.ReadLine());
                sum = sum + num;
            }
            while(num != -1);
            sum = sum + 1;
            Console.Write("The total sum = " + sum);
            Console.ReadKey();
        }
    }
}*/



/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] number = new int[3];
            for (int i = 0; i < 3; i++) {
                Console.Write("Enter a number = ");
                number[i]= int.Parse(Console.ReadLine());
            }
            int largest = -1;
            for (int i = 0; i < 3; i++)
            {
                if (number[i] > largest)
                {
                    largest = number[i];
                }
            }
            Console.WriteLine("Largest Number = "+ largest);
            Console.ReadKey();
        }
    }
}*/


/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter Lilly Age = ");
            int age = int.Parse(Console.ReadLine());
            Console.Write("Enter Price Of Washing Machine = ");
            double wprice = double.Parse(Console.ReadLine());
            Console.Write("Enter Unit Price Of Toy = ");
            Console.Write("");
            double tprice = double.Parse(Console.ReadLine());
            double tmoney;
            double emoney = 0;
            double omoney = 0;
            for (int i = 0; i < age; i++)
            {
                if (i % 2 == 0)
                    emoney += (10 * (i / 2)) - 1; 
                else
                    omoney += tprice; 
            }
            tmoney = emoney + omoney;
            if (tmoney > wprice)
            {
                Console.Write("Yes,She can buy the washimg machine");
            }
            else
            {
                Console.Write("No,She cannot but the washing machine");
            }
        }
    }
}*/



