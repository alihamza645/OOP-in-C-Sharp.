﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace _1
{
    class MUser
    {
        public string name;
        public string password;
        public string role;

        
        public static List<MUser> users = new List<MUser>();

        public MUser(string name, string password)
        {
            this.name = name;
            this.password = password;
        }

        public MUser(string name, string password, string role)
        {
            this.name = name;
            this.password = password;
            this.role = role;
        }

        public bool isAdmin()
        {
            return role == "Admin";
        }

        
        public static void storeDataInList(MUser user)
        {
            users.Add(user);
        }
    }

    internal class Program
    {
        static string path = "textfile.txt";

        static int menu()
        {
            int option;
            Console.WriteLine("1. SignIn");
            Console.WriteLine("2. SignUp");
            Console.Write("Enter Option = ");
            option = int.Parse(Console.ReadLine());
            return option;
        }

        static bool readData()
        {
            if (File.Exists(path))
            {
                StreamReader fileVariable = new StreamReader(path);
                string record;
                while ((record = fileVariable.ReadLine()) != null)
                {
                    string name = parseData(record, 1);
                    string password = parseData(record, 2);
                    string role = parseData(record, 3);
                    MUser user = new MUser(name, password, role);
                    MUser.storeDataInList(user); 
                }
                fileVariable.Close();
                return true;
            }
            return false;
        }

        static string parseData(string record, int field)
        {
            int comma = 1;
            string item = "";
            for (int i = 0; i < record.Length; i++)
            {
                if (record[i] == ',')
                {
                    comma++;
                }
                else if (comma == field)
                {
                    item += record[i];
                }
            }
            return item;
        }

        static MUser takeInputWithoutRole()
        {
            Console.Write("Enter Name = ");
            string name = Console.ReadLine();
            Console.Write("Enter Password = ");
            string password = Console.ReadLine();
            if (name != null && password != null)
            {
                return new MUser(name, password);
            }
            return null;
        }

        static MUser takeInputWithRole()
        {
            Console.Write("Enter Name = ");
            string name = Console.ReadLine();
            Console.Write("Enter Password = ");
            string password = Console.ReadLine();
            Console.Write("Enter Role = ");
            string role = Console.ReadLine();
            if (name != null && password != null && role != null)
            {
                return new MUser(name, password, role);
            }
            return null;
        }

        static void storeDataInFile(MUser user)
        {
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(user.name + ',' + user.password + ',' + user.role);
            file.Flush();
            file.Close();
        }

        static MUser signIn(MUser user)
        {
            foreach (MUser storeUser in MUser.users)
            {
                if (user.name == storeUser.name && user.password == storeUser.password)
                {
                    return storeUser;
                }
            }
            return null;
        }

        static void Main(string[] args)
        {
            int option;
            bool check = readData();
            Console.WriteLine(check ? "Data Loaded Successfully" : "Data not Loaded");
            Console.ReadKey();

            do
            {
                Console.Clear();
                option = menu();
                Console.Clear();

                if (option == 1)
                {
                    MUser user = takeInputWithoutRole();
                    if (user != null)
                    {
                        user = signIn(user);
                        if (user == null)
                            Console.WriteLine("Invalid User");
                        else if (user.isAdmin())
                            Console.WriteLine("Admin Menu");
                        else
                            Console.WriteLine("User Menu");
                    }
                }
                else if (option == 2)
                {
                    MUser user = takeInputWithRole();
                    if (user != null)
                    {
                        storeDataInFile(user);
                        MUser.storeDataInList(user); 
                    }
                }

                Console.ReadKey();
            }
            while (option < 3);
        }
    }
}








