﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1
{
    class Student
    {
        public string name;
        public int rollno;
    }

    internal class Program
    {
      

        static void Main(string[] args)
        {
            Student s1=new Student();
            s1.name = "Ali";
            s1.rollno = 20;
            Student s2=new Student();
            s2.name = "Hamza";
            s2.rollno = 30;
            Console.WriteLine(s1.name+" "+ s1.rollno);
            Console.WriteLine(s2.name+" "+s2.rollno);
        }
    }
}*/




/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1
{

    internal class Program
    {
        class Student
        {
            public string name;
            public int rollno;

            public Student()
            {
                name = "Unknown";
                rollno = 10;
            }
        }
      

        static void Main(string[] args)
        {
           Student student = new Student();
            Console.WriteLine(student.name+" "+student.rollno);
        }
    }
}*/


/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1
{
    class Student
    {
        public string name;
        public int rollno;
        public Student(string n, int r)
        {
            name = n;
            rollno = r;
        }
    }

    internal class Program
    {
      

        static void Main(string[] args)
        {
            Student s1 = new Student("Hamza", 10);
            Student s2 = new Student("Ali", 20);
            Console.WriteLine(s1.name + " " + s1.rollno);
            Console.WriteLine(s2.name + " " + s2.rollno);
              
        }
    }
}*/



/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1
{
  class Student
    {
        public string name;
        public int matric;
        public int fsc;
        public int ecat;

        public Student()
        {
            name = "Unknow";
            matric = 0;
            fsc = 0;
            ecat = 0; 
        }
        public Student(string n, int m, int f, int e)
        {
            name = n;
            matric = m;
            fsc = f;
            ecat =e;
        }
    }

    internal class Program
    {
      

        static void Main(string[] args)
        {
            Student s1=new Student();
            Console.WriteLine("Default Constructor Student");
            Console.WriteLine(s1.name+" "+s1.matric+" "+s1.fsc+" "+s1.ecat);
            Student s2=new Student("Hamza",1000,1000,300);
            Console.WriteLine("Parametarized Constructor Student");
            Console.WriteLine(s2.name + " " + s2.matric + " " + s2.fsc + " " + s2.ecat);
            Console.ReadKey();
        }
    }
}*/



/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1
{
    class Book
    {
        public string title;
        public string author;
        public double price;
        public Book()
        {
            title = "Unknow";
            author = "Unknow";
            price = 0;
        }
    }


    internal class Program
    {
      

        static void Main(string[] args)
        {
            Book first=new Book();
            Console.WriteLine(first.title+" "+first.author+" "+first.price);
            Book second = new Book();
            Console.WriteLine(second.title+" "+second.author+" "+second.price);
        }
    }
}*/


/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1
{
    class Car
    {
        public string brand;
        public string model;
        public double price;
        public Car(string b, string m, double p)
        {
            brand = b;
            model = m;
            price = p;
        }
    }

    internal class Program
    {
      

        static void Main(string[] args)
        {
            Car first = new Car("Honda", "2025", 15000);
            Console.WriteLine("Brand" + " " + " Model" + " " + "Price");
            Console.WriteLine(first.brand+"  "+first.model+"  "+first.price);
            Car second = new Car("Bently", "2022", 900000);
            Console.WriteLine(second.brand + " " + second.model + " " + second.price);
        }
    }
}*/




/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace _2ndlab
{
    class BankAccount
    {
        public BankAccount()
        {
            AccountNo = 0;
            HolderName = "unknown";
            Balance = 0f;
        }
        public BankAccount(int a, string b, float ba)
        {
            AccountNo = a;
            HolderName = b;
            Balance = ba;
        }
        public int AccountNo;
        public string HolderName;
        public float Balance;
    }
    class Program
    {
        static void Main(string[] args)
        {
            BankAccount user1 = new BankAccount();
            BankAccount user2 = new BankAccount(2, "Hamza", 1200f);
            Console.WriteLine(user1.AccountNo + "\t" + user1.HolderName + "\t" + user1.Balance);
            Console.WriteLine(user2.AccountNo + "\t" + user2.HolderName + "\t" + user2.Balance);
            Console.ReadKey();
        }
    }
}*/




/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1
{

    internal class Program
    {
      class Bankaccount
        {
            public int accountnumber;
            public string holdername;
            public double balance;
            public Bankaccount()
            {
                accountnumber = 0;
                holdername = "Unknow";
                balance = 0.0;
            }
            public Bankaccount(int an, string hn, double b)
            {
                accountnumber = an;
                holdername = hn;
                balance = b;
            }
            public void ShowDetails()
            {
                Console.WriteLine("Account Number: " + accountnumber);
                Console.WriteLine("Holder Name: " + holdername);
                Console.WriteLine("Balance: $" + balance);
                Console.WriteLine("---------------------------");
            }

        }

        static void Main(string[] args)
        {
        
            Bankaccount account1=new Bankaccount();
            account1.ShowDetails();
            Bankaccount account2= new Bankaccount(12345,"ALI",5000);
            account2.ShowDetails();
            Bankaccount account3 = new Bankaccount(45454, "HAMZA", 9000);
            account3.ShowDetails();
            Bankaccount account4 = new Bankaccount(13131, "HASSAN", 8000);
            account4.ShowDetails();
        }
    }
}*/



/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1
{
   class Transction
    {
        public int id;
        public string productname;
        public double amount;
        public string date;
        public string time;
        public Transction()
        {
            id = 0;
            productname = "Unknown";
            amount = 0;
            date = "Not Set";
            time = "Not Set";
        }
        public Transction(int i,string pn, double a,string d,string t)
        {
            id = i;
            productname = pn;
            amount = a;
            date = d;
            time = t;
        }
        public void Showdetails()
        {
            Console.WriteLine("Transction id = " + id);
            Console.WriteLine("Product Name = " + productname);
            Console.WriteLine("Amount = " + amount);
            Console.WriteLine("Date = " + date);
            Console.WriteLine("Time = " + time);
            Console.WriteLine("*****************************************************");
            
        }
    }

    internal class Program
    {

        static void Main(string[] args)
        {
            Transction first=new Transction();
            first.Showdetails();
            Transction second = new Transction(10, "Laptop", 10000, "10/1/2024", "12pm");
            second.Showdetails();
        }
    }
}*/




/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1
{
    class Calculator
    {
        public double firstnumber;
        public double secondnumber;
        public Calculator(double fn,double sn)
        {
            firstnumber = fn;
            secondnumber = sn;
        }
        public double addition()
        {
            return firstnumber + secondnumber;
        }
        public double subctraction()
        {
            return firstnumber - secondnumber;
        }
        public double division()
        {
            return firstnumber / secondnumber;
        }
        public double multi()
        {
            return firstnumber * secondnumber;
        }
    }

    internal class Program
    {


        static void Main(string[] args)
        {
            Calculator numbers = new Calculator(5, 2);
            Console.WriteLine("Addition = "+ numbers.addition());
            Console.WriteLine("Subctraction = "+numbers.subctraction());
            Console.WriteLine("Multiplication = "+numbers.multi());
            Console.WriteLine("Division = "+numbers.division());
        }
    }
}*/



/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class ATM
{
    public double balance;
    public ATM()
    {
        balance = 0;
        Console.WriteLine("ATM initialized with starting balance: "+balance);
    }

    public ATM(double initialBalance)
    {
        if (initialBalance < 0)
        {
            Console.WriteLine("Initial balance cannot be negative. Setting to 0.");
            balance = 0;
        }
        else
        {
            balance = initialBalance;
            Console.WriteLine("ATM initialized with starting balance: "+balance);
        }
    }
    public void Deposit(double amount)
    {
        if (amount <= 0)
        {
            Console.WriteLine("Deposit amount must be greater than 0.");
            return;
        }
        balance += amount;
        Console.WriteLine("Deposited = " +amount+ "New balance = " +balance);
    }
    public void Withdraw(double amount)
    {
        if (amount <= 0)
        {
            Console.WriteLine("Withdrawal amount must be greater than 0.");
            return;
        }
        if (amount > balance)
        {
            Console.WriteLine("Insufficient balance. Withdrawal denied.");
        }
        else
        {
            balance -= amount;
            Console.WriteLine($"Withdraw: {amount}. New balance: {balance}");
        }
    } 
    public double CheckBalance()
    {
        return balance;
    }
    static void Main(string[] args)
    {
        
        ATM atm1 = new ATM();
        atm1.Deposit(500);
        atm1.Withdraw(10);
        Console.WriteLine("Final Balance (ATM1) = " + atm1.CheckBalance());
        Console.WriteLine("******************************************************************");
        
        ATM atm2 = new ATM(1000);
        atm2.Deposit(250);
        atm2.Withdraw(500);
        Console.WriteLine("Final Balance (ATM2) =  " + atm2.CheckBalance());
        Console.ReadKey();
    }
}*/



/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
class Student
{
    public string name;
    public double matricMarks;
    public double fscMarks;
    public double ecatMarks;
    public double aggregate;

    public Student(string n, double matric, double fsc, double ecat)
    {
        name = n;
        matricMarks = matric;
        fscMarks = fsc;
        ecatMarks = ecat;
        aggregate = (matric / 1100 * 10) + (fsc / 1100 * 40) + (ecat / 400 * 50);
    }

    public void Show()
    {
        Console.WriteLine("Name = " + name);
        Console.WriteLine("Matric = " + matricMarks);
        Console.WriteLine("FSC = " + fscMarks);
        Console.WriteLine("ECAT = " + ecatMarks);
        Console.WriteLine("Aggregate = " + aggregate.ToString("F2"));
        Console.WriteLine();
    }
}

class Program
{
    static void Main()
    {
        Student[] students = new Student[100]; 
        int count = 0;
        int choice = 0;
        Console.WriteLine("                                                        Main Menu                                 ");

        while (choice != 5)
        {
            Console.WriteLine("1. Add Student");
            Console.WriteLine("2. Show Students");
            Console.WriteLine("3. Calculate Aggregate");
            Console.WriteLine("4. Top Students");
            Console.WriteLine("5. Exit");
            Console.Write("Enter your choice: ");
            choice = int.Parse(Console.ReadLine());

            if (choice == 1)
            {
                Console.Write("Enter Name: ");
                string name = Console.ReadLine();
                Console.Write("Enter Matric Marks: ");
                double matric = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter FSC Marks: ");
                double fsc = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter ECAT Marks: ");
                double ecat = Convert.ToDouble(Console.ReadLine());

                students[count] = new Student(name, matric, fsc, ecat);
                count++;
                Console.WriteLine("Student Added.\n");
            }
            else if (choice == 2)
            {
                Console.WriteLine("\n--- Student List ---");
                for (int i = 0; i < count; i++)
                {
                    students[i].Show();
                }
            }
            else if (choice == 3)
            {
                Console.WriteLine("--- Aggregates ---");
                for (int i = 0; i < count; i++)
                {
                    Console.WriteLine(students[i].name + " Aggregate = " + students[i].aggregate.ToString("F2"));
                }
                Console.WriteLine();
            }
            else if (choice == 4)
            {
                Console.WriteLine("--- Top 3 Students ---");
                
                for (int i = 0; i < count - 1; i++)
                {
                    for (int j = i + 1; j < count; j++)
                    {
                        if (students[j].aggregate > students[i].aggregate)
                        {
                            Student temp = students[i];
                            students[i] = students[j];
                            students[j] = temp;
                        }
                    }
                }

                for (int i = 0; i < Math.Min(3, count); i++)
                {
                    students[i].Show();
                }
            }
        }
    }
}*/



/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
class Product
{
    public int id;
    public string name;
    public double price;
    public string category;
    public string brandname;
    public string country;

    public Product(int i, string n, double p, string ca, string b, string c)
    {
        id = i;
        name = n;
        price = p;
        category = ca;
        brandname = b;
        country = c;

    }
    public void Showproducts()
    {
        Console.WriteLine("Product id = " + id.ToString());
        Console.WriteLine("Product name = " + name);
        Console.WriteLine("Product price = " + price.ToString());
        Console.WriteLine("Product category" + category);
        Console.WriteLine("Product brand name = " + brandname);
        Console.WriteLine("Product country = " + country);
        Console.WriteLine();
    }
    

}



internal class Program
{


    static void Main(string[] args)
    {
        Product[] products = new Product[100];
        int count = 0;
        int choice = 0;
        Console.WriteLine("                           *******Main Menu*******");

        while (choice != 4)
        {
            Console.WriteLine("1.Add Products. ");
            Console.WriteLine("2.Show Products.");
            Console.WriteLine("3.Total Store Worth.");
            Console.WriteLine("4.Exit");
            Console.WriteLine("Enter your choice.");
            choice = int.Parse(Console.ReadLine());
            Console.Clear();

            if (choice == 1)
            {
                Console.Clear();
                Console.Write("Enter Product id = ");
                int id = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Product name = ");
                string name = Console.ReadLine();
                Console.Write("Enter Product Price = ");
                double price = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter Product Category = ");
                string category = Console.ReadLine();
                Console.Write("Enter Brand Name = ");
                string brandname = Console.ReadLine();
                Console.Write("Enter Country Name = ");
                string country = Console.ReadLine();

                products[count] = new Product(id, name, price, category, brandname, country);
                count++;
                Console.WriteLine("              *****Product added succesfully*****           ");
                Console.WriteLine();
            }
            else if (choice == 2)
            {
                Console.Clear();
                Console.WriteLine("*****Product List*****");
                for (int i = 0; i < count; i++)
                {
                    products[i].Showproducts();
                }
            }
            else if (choice == 3)
            {
                Console.Clear();
                double totalWorth = 0;
                for (int i = 0; i < count; i++)
                {
                    totalWorth += products[i].price;
                }
                Console.WriteLine("*****Total Store Worth*****");
                Console.WriteLine("Total value of all products = " + totalWorth.ToString("F2"));

            }
            }
        }
    }*/


using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1
{
    class MUser
    {
        public string name;
        public string password;
        public string role;
        public MUser(string name, string password) {
            this.name = name;
            this.password = password;
        }
        public MUser(string name, string password, string role)
        {
            this.name = name;
            this.password = password;
            this.role = role;
        }
        public bool isAdmin()
        {
            if (role == "Admin")
            {
                return true;
            }
            return false;
        }
    }



    internal class Program
    {
        static int menu()
        {
            int option;
            Console.WriteLine("1.SignIn ");
            Console.WriteLine("2.SignUp ");
            Console.Write("Enter Option = ");
            option = int.Parse(Console.ReadLine());
            return option;

        }

        static bool readData(string path, List<MUser> users)
        {
            if (File.Exists(path))
            {
                StreamReader fileVariable = new StreamReader(path);
                string record;
                while ((record = fileVariable.ReadLine()) != null)
                {
                    string name = parseData(record, 1);
                    string password = parseData(record, 2);
                    string role = parseData(record, 3);
                    MUser user = new MUser(name, password);
                    storeDataInList(users, user);
                }
                fileVariable.Close();
                return true;
            }
            return false;
        }
        static string parseData(string record, int field) {
            int comma = 1;
            string item = "";
            for (int i = 0; i < record.Length; i++)
            {
                if (record[i] == ',')
                {
                    comma++;
                }
                else if (comma == field)
                {
                    item = item + record[i];
                }
            }
            return item;
        }
        static MUser takeInputWithoutRole()
        {
            Console.Write("Enter Name = ");
            string name = Console.ReadLine();
            Console.Write("Enter Password = ");
            string password = Console.ReadLine();
            if (name != null && password != null)
            {
                MUser user = new MUser(name, password);
                return user;
            }
            return null;
        }
        static MUser takeInputWithRole()
        {
            Console.Write("Enter Name = ");
            string name = Console.ReadLine();
            Console.Write("Enter Password = ");
            string password = Console.ReadLine();
            Console.Write("Enter Role = ");
            string role = Console.ReadLine();
            if (name != null && password != null && role != null)
            {
                MUser user = new MUser(name, password, role);
                return user;
            }
            return null;
        }
        static void storeDataInList(List<MUser> users, MUser user)
        {
            users.Add(user);
        }
        static void storeDataInFile(string path, MUser user)
        {
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(user.name + ',' + user.password + ',' + user.role);
            file.Flush();
            file.Close();
        }
        static MUser signIn(MUser user, List<MUser> users) {
            foreach (MUser storeUser in users)
            {
                if (user.name == storeUser.name && user.password == storeUser.password)
                {
                    return storeUser;
                }
            }
            return null;
        }

        static void Main(string[] args)
        {
            List<MUser> users = new List<MUser>();
            string path = "textfile.txt";
            int option;
            bool check = readData(path, users);
            if (check) {
                Console.WriteLine("Data Loaded Successfully"); }
            else {
                Console.WriteLine("Data not Loaded");
            }
            Console.ReadKey();
            do
            {
                Console.Clear();
                option = menu();
                Console.Clear();
                if (option == 1)
                {
                    MUser user = takeInputWithoutRole();
                    if ((user != null)){
                        user = signIn(user, users);
                        if (user == null)
                            Console.WriteLine("Invalid User");
                        else if (user.isAdmin())
                            Console.WriteLine("Admin Menu");
                        else Console.WriteLine("User Menu");


                    }
                }
                else if (option == 2)
                {
                    MUser user = takeInputWithRole();
                    if ((user != null))
                        {
                        storeDataInFile(path, user);
                        storeDataInList(users, user);
                    }
                }
                Console.ReadKey();
            }
            while (option < 3); }

    } }


                
            
        
    

