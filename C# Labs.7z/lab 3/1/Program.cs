﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1
{
    public class Student
    {
        public string name;
        public int RollNo;
        public float cgpa;
        public int matricmarks;
        public int fscmarks;
        public int ecatmarks;
        public string hometown;
        public bool ishostellite;
        public bool istakingscholarship;
        public float calculatemerit(float merit)
        {
            merit = ((matricmarks / 1100F) * 0.25F + (fscmarks / 1200F) * 0.45F + (ecatmarks / 400) * 0.30F);
            return merit * 100;
        }
        public bool iseligibleforscholarship(float merit)
        {
            if (merit > 50)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public Student(string name, int rollNo, float cgpa, int matricmarks, int fscmarks, int ecatmarks, string hometown, bool ishostellite, bool istakingscholarship)
        {
            this.name = name;
            RollNo = rollNo;
            this.cgpa = cgpa;
            this.matricmarks = matricmarks;
            this.fscmarks = fscmarks;
            this.ecatmarks = ecatmarks;
            this.hometown = hometown;
            this.ishostellite = ishostellite;
            this.istakingscholarship = istakingscholarship;
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Student s1 = new Student("Haseeb Ahmad", 142, 3.22F, 1004, 1081, 231, "Lahore", false, false);
            Console.WriteLine("Student name: " + s1.name);
            Console.WriteLine("Student roll no: " + s1.RollNo);
            Console.WriteLine("Cgpa: " + s1.cgpa);
            Console.WriteLine("Matric marks: " + s1.matricmarks);
            Console.WriteLine("fsc marks: " + s1.fscmarks);
            Console.WriteLine("ecat marks: " + s1.ecatmarks);
            Console.WriteLine("is hostellite: " + s1.ishostellite);
            float merit = s1.calculatemerit(0);
            Console.WriteLine("Merit percentage: " + merit + "%");
            if (s1.iseligibleforscholarship(merit))
            {
                Console.WriteLine("status: Eligible for scholarship");
            }
            else
            {
                Console.WriteLine("Status: Not eligible for scholarship");
            }
            Console.ReadKey();
        }

    }
}*/





/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1
{
    public class Book
    {
        public string title;
        public string author;
        public int pages;
        public List<string> chapters;
        public int bookmark;
        public int price;
        public bool isavailable;
        public Book(string title, string author, int pages, List<string> chapters, int bookmark, int price, bool isavailable)
        {
            this.title = title;
            this.author = author;
            this.pages = pages;
            this.chapters = chapters;
            this.bookmark = bookmark;
            this.price = price;
            this.isavailable = isavailable;
        }
        public bool isbookavailable()
        {
            return isavailable;
        }
        public string getchapter(int chapternumber)
        {
            if (chapternumber > 0 && chapternumber <= chapters.Count)
            {
                return chapters[chapternumber - 1];
            }
            else
            {
                return "Invalid chapter number";
            }
        }
        public int getbookmark()
        {
            return bookmark;
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            List<string> chapters = new List<string>()
        {
            "introduction to c#","Classes and object in c#","behaviour of class",
            "functions in c#"
        };
            Book b1 = new Book("Object oriented programming", "Kalvin", 200, chapters, 100, 2000, true);
            Console.WriteLine("booktitle: " + b1.title);
            Console.WriteLine("Author: " + b1.author);
            Console.WriteLine("Pages: " + b1.pages);
            Console.WriteLine("Chapter 3: " + b1.getchapter(3));
            Console.WriteLine("Book mark page: " + b1.bookmark);
            Console.WriteLine("Price: " + b1.price);
            Console.WriteLine("Is book available: " + b1.isbookavailable());
            Console.ReadKey();
        }
    }
}*/







/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1
{
    public class Customer
    {
        public string customername;
        public string customeraddress;
        public string customercontact;
        public List<Product> products = new List<Product>();
        public List<Product> getallproducts()
        {
            return products;
        }
        public void addproduct(Product p)
        {
            products.Add(p);
        }
        public float calculatetotaltax()
        {
            float totaltax = 0;
            foreach (var p in products)
            {
                totaltax += p.price;
            }
            return totaltax;
        }
        public Customer(string customername, string customeraddress, string customercontact)
        {
            this.customername = customername;
            this.customeraddress = customeraddress;
            this.customercontact = customercontact;
        }
    }
    public class Product
    {
        public string name;
        public string category;
        public int price;
        public Product(string name, string category, int price)
        {
            this.name = name;
            this.category = category;
            this.price = price;
        }
        public float calculatetax()
        {
            return price * 0.20F;
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Customer c1 = new Customer("Fahad", "Attock", "01234567891");
            Product p1 = new Product("CPU", "Electronics", 100000);
            Product p2 = new Product("Laptop", "Electronics", 20000);
            c1.addproduct(p1);
            c1.addproduct(p2);
            Console.WriteLine("Products purchased by Customer: " + c1.customername);
            foreach (var p in c1.products)
            {
                Console.WriteLine($"Productname: {p.name},category: {p.category},price: {p.price},Tax: {p.calculatetax()}");
            }
            Console.WriteLine("Tax on all products is: " + c1.calculatetotaltax());
            Console.ReadKey();
        }
    }
}*/




/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1
{
    public class Book
    {
        public string title;
        public string author;
        public string publisher;
        public string isbn;
        public double price;
        public int stock;

        public void ShowBook()
        {
            Console.WriteLine("Title: " + title);
            Console.WriteLine("Author: " + author);
            Console.WriteLine("Publisher: " + publisher);
            Console.WriteLine("ISBN: " + isbn);
            Console.WriteLine("Price: " + price);
            Console.WriteLine("Stock: " + stock);
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Book[] library = new Book[50];
            int count = 0;
            int choice;
            do
            {
                Console.WriteLine("* BOOK MENU *");
                Console.WriteLine("1. Add Book");
                Console.WriteLine("2. Search by Title");
                Console.WriteLine("3. Search by ISBN");
                Console.WriteLine("4. Update Stock");
                Console.WriteLine("5. Exit");
                Console.Write("Enter choice: ");
                choice = int.Parse(Console.ReadLine());

                if (choice == 1)
                {
                    Console.Clear();
                    library[count] = new Book();

                    Console.Write("Enter Title: ");
                    library[count].title = Console.ReadLine();

                    Console.Write("Enter Author: ");
                    library[count].author = Console.ReadLine();

                    Console.Write("Enter Publisher: ");
                    library[count].publisher = Console.ReadLine();

                    Console.Write("Enter ISBN: ");
                    library[count].isbn = Console.ReadLine();

                    Console.Write("Enter Price: ");
                    library[count].price = double.Parse(Console.ReadLine());

                    Console.Write("Enter Stock: ");
                    library[count].stock = int.Parse(Console.ReadLine());

                    count++;
                    Console.WriteLine("Book Added Successfully!");
                }
                else if (choice == 2)
                {
                    Console.Clear();
                    Console.Write("Enter Title to Search: ");
                    string title = Console.ReadLine();
                    bool found = false;

                    for (int i = 0; i < count; i++)
                    {
                        if (library[i].title == title)
                        {
                            library[i].ShowBook();
                            found = true;
                            break;
                        }
                    }
                    if (!found)
                    {
                        Console.WriteLine("Book Not Found!");
                    }
                }
                else if (choice == 3)
                {
                    Console.Clear();
                    Console.Write("Enter ISBN to Search: ");
                    string id = Console.ReadLine();
                    bool found = false;

                    for (int i = 0; i < count; i++)
                    {
                        if (library[i].isbn == id)
                        {
                            library[i].ShowBook();
                            found = true;
                            break;
                        }
                    }
                    if (!found)
                    {
                        Console.WriteLine("Book Not Found!");
                    }
                }
                else if (choice == 4)
                {
                    Console.Clear();
                    Console.Write("Enter ISBN to Update Stock: ");
                    string id = Console.ReadLine();
                    bool found = false;

                    for (int i = 0; i < count; i++)
                    {
                        if (library[i].isbn == id)
                        {
                            Console.Write("Enter New Stock: ");
                            library[i].stock = int.Parse(Console.ReadLine());
                            Console.WriteLine("Stock Updated!");
                            found = true;
                            break;
                        }
                    }
                    if (!found)
                    {
                        Console.WriteLine("Book Not Found!");
                    }
                }

            } while (choice != 5);
        }
    }
}*/






/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1
{
    public class Member
    {
        public string name;
        public int memberid;
        public string[] booksbought = new string[50];
        public int numberofbooks;
        public double moneyinbank;
        public double amountspent;
        public void ShowMember()
        {
            Console.WriteLine("Name: " + name);
            Console.WriteLine("Member ID: " + memberid);
            Console.WriteLine("Money in Bank: " + moneyinbank);
            Console.WriteLine("Amount Spent: " + amountspent);
            Console.WriteLine("Books Bought: " + numberofbooks);
        }
        public void AddBook(string bookName, double price)
        {
            booksbought[numberofbooks] = bookName;
            numberofbooks++;
            amountspent += price;
            moneyinbank -= price;
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Member m = new Member();
            int choice;
            do
            {
                Console.WriteLine("* MEMBER MENU *");
                Console.WriteLine("1. Set Member Info");
                Console.WriteLine("2. Buy a Book");
                Console.WriteLine("3. Show Member Info");
                Console.WriteLine("4. Exit");
                Console.Write("Enter choice: ");
                choice = int.Parse(Console.ReadLine());
                if (choice == 1)
                {
                    Console.Clear();
                    Console.Write("Enter Name: ");
                    m.name = Console.ReadLine();

                    Console.Write("Enter Member ID: ");
                    m.memberid = int.Parse(Console.ReadLine());

                    Console.Write("Enter Money in Bank: ");
                    m.moneyinbank = double.Parse(Console.ReadLine());

                    Console.WriteLine("member info saved successfully!");
                }
                else if (choice == 2)
                {
                    Console.Clear();
                    Console.Write("Enter Book Name: ");
                    string bookName = Console.ReadLine();

                    Console.Write("Enter Book Price: ");
                    double price = double.Parse(Console.ReadLine());

                    m.AddBook(bookName, price);
                    Console.WriteLine("Book Bought!");
                }
                else if (choice == 3)
                {
                    Console.Clear();
                    m.ShowMember();
                }
            } while (choice != 4);
        }
    }
}*/






/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1
{
    class Book
    {
        public string Title;
        public string Author;
        public string ISBN;
        public double Price;
        public int Stock;

        public Book(string title, string author, string isbn, double price, int stock)
        {
            Title = title;
            Author = author;
            ISBN = isbn;
            Price = price;
            Stock = stock;
        }

        public void ShowBook()
        {
            Console.WriteLine($"Title: {Title}, Author: {Author}, ISBN: {ISBN}, Price: {Price}, Stock: {Stock}");
        }
    }
    class Member
    {
        public string Name;
        public int MemberID;
        public int BooksBought;
        public double AmountSpent;

        public Member(string name, int id)
        {
            Name = name;
            MemberID = id;
            BooksBought = 0;
            AmountSpent = 0;
        }

        public void ShowMember()
        {
            Console.WriteLine($"Name: {Name}, ID: {MemberID}, Books Bought: {BooksBought}, Amount Spent: {AmountSpent}");
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            List<Book> books = new List<Book>();
            List<Member> members = new List<Member>();

            double totalSales = 0;
            double membershipFeeCollected = 0;
            int choice;
            do
            {
                Console.Clear();
                Console.WriteLine("==== BOOKSTORE MENU ====");
                Console.WriteLine("1. Add Book");
                Console.WriteLine("2. Search Book by Title");
                Console.WriteLine("3. Search Book by ISBN");
                Console.WriteLine("4. Update Book Stock");
                Console.WriteLine("5. Add Member");
                Console.WriteLine("6. Search Member");
                Console.WriteLine("7. Update Member");
                Console.WriteLine("8. Purchase Book");
                Console.WriteLine("9. Display Total Sales and Stats");
                Console.WriteLine("0. Exit");
                Console.Write("Enter choice: ");
                choice = int.Parse(Console.ReadLine());
                Console.Clear();
                if (choice == 1)
                {
                    Console.Write("Enter Title: ");
                    string title = Console.ReadLine();
                    Console.Write("Enter Author: ");
                    string author = Console.ReadLine();
                    Console.Write("Enter ISBN: ");
                    string isbn = Console.ReadLine();
                    Console.Write("Enter Price: ");
                    double price = double.Parse(Console.ReadLine());
                    Console.Write("Enter Stock: ");
                    int stock = int.Parse(Console.ReadLine());

                    books.Add(new Book(title, author, isbn, price, stock));
                    Console.WriteLine("Book Added Successfully!");
                }
                else if (choice == 2)
                {
                    Console.Write("Enter Title to Search: ");
                    string t = Console.ReadLine();
                    bool found = false;

                    foreach (var b in books)
                    {
                        if (b.Title == t)
                        {
                            b.ShowBook();
                            found = true;
                            break;
                        }
                    }

                    if (!found)
                        Console.WriteLine("Book Not Found!");
                }
                else if (choice == 3)
                {
                    Console.Write("Enter ISBN to Search: ");
                    string i = Console.ReadLine();
                    bool found = false;

                    foreach (var b in books)
                    {
                        if (b.ISBN == i)
                        {
                            b.ShowBook();
                            found = true;
                            break;
                        }
                    }

                    if (!found)
                        Console.WriteLine("Book Not Found!");
                }
                else if (choice == 4)
                {
                    Console.Write("Enter Title or ISBN: ");
                    string input = Console.ReadLine();
                    bool found = false;

                    foreach (var b in books)
                    {
                        if (b.Title == input || b.ISBN == input)
                        {
                            Console.Write("Enter New Stock: ");
                            b.Stock = int.Parse(Console.ReadLine());
                            Console.WriteLine("Stock Updated!");
                            found = true;
                            break;
                        }
                    }

                    if (!found)
                        Console.WriteLine("Book Not Found!");
                }
                else if (choice == 5)
                {
                    Console.Write("Enter Member Name: ");
                    string name = Console.ReadLine();
                    Console.Write("Enter Member ID: ");
                    int id = int.Parse(Console.ReadLine());

                    members.Add(new Member(name, id));
                    membershipFeeCollected += 10;

                    Console.WriteLine("Member Added Successfully! ($10 Membership Fee Applied)");
                }
                else if (choice == 6)
                {
                    Console.Write("Enter Member Name or ID to Search: ");
                    string input = Console.ReadLine();
                    bool found = false;

                    foreach (var m in members)
                    {
                        if (m.Name == input || m.MemberID.ToString() == input)
                        {
                            m.ShowMember();
                            found = true;
                            break;
                        }
                    }

                    if (!found)
                        Console.WriteLine("Member Not Found!");
                }
                else if (choice == 7)
                {
                    Console.Write("Enter Member Name or ID to Update: ");
                    string input = Console.ReadLine();
                    bool found = false;

                    foreach (var m in members)
                    {
                        if (m.Name == input || m.MemberID.ToString() == input)
                        {
                            Console.Write("Enter New Name: ");
                            m.Name = Console.ReadLine();
                            Console.Write("Enter New ID: ");
                            m.MemberID = int.Parse(Console.ReadLine());

                            Console.WriteLine("Member Updated Successfully!");
                            found = true;
                            break;
                        }
                    }
                }
                else if (choice == 8)
                {
                    Console.Write("Enter Member ID (0 for non-member): ");
                    int id = int.Parse(Console.ReadLine());

                    Member member = null;
                    if (id != 0)
                    {
                        foreach (var m in members)
                        {
                            if (m.MemberID == id)
                            {
                                member = m;
                                break;
                            }
                        }

                        if (member == null)
                        {
                            Console.WriteLine("Member Not Found!");
                            goto SkipPurchase;
                        }
                    }

                    Console.Write("Enter Book Title or ISBN to Purchase: ");
                    string input = Console.ReadLine();
                    Book book = null;

                    foreach (var b in books)
                    {
                        if (b.Title == input || b.ISBN == input)
                        {
                            book = b;
                            break;
                        }
                    }

                    if (book == null)
                    {
                        Console.WriteLine("Book Not Found!");
                        goto SkipPurchase;
                    }

                    Console.Write("Enter Quantity: ");
                    int qty = int.Parse(Console.ReadLine());

                    if (qty > book.Stock)
                    {
                        Console.WriteLine("Not Enough Stock!");
                        goto SkipPurchase;
                    }
                    double totalPrice = qty * book.Price;
                    if (member != null)
                        totalPrice -= totalPrice * 0.05;
                    book.Stock -= qty;
                    if (member != null)
                    {
                        member.BooksBought += qty;
                        member.AmountSpent += totalPrice;
                        if (member.BooksBought >= 11)
                        {
                            double avg = member.AmountSpent / 10;
                            Console.WriteLine($"Special Discount Applied: {avg}");
                            totalPrice -= avg;
                            member.AmountSpent = 0;
                            member.BooksBought = 1; // Restart count (current book becomes 1)
                        }
                    }

                    totalSales += totalPrice;
                    Console.WriteLine($"Purchase Successful! Total Bill: {totalPrice}");

                SkipPurchase:;
                }
                Console.WriteLine("Press any key to continue.");
                Console.ReadKey();
            } while (choice != 0);
        }
    }
}*/






using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1
{
    class Subject
    {
        public string Code;
        public string Type;
        public int CreditHours;
        public double Fee;

        public Subject(string code, string type, int creditHours, double fee)
        {
            Code = code;
            Type = type;
            CreditHours = creditHours;
            Fee = fee;
        }

        public void ShowSubject()
        {
            Console.WriteLine($"[{Code}] {Type} | CH: {CreditHours} | Fee: {Fee}");
        }
    }


    class DegreeProgram
    {
        public string Title;
        public double DurationYears;
        public int Seats;
        public List<Subject> Subjects;

        public DegreeProgram(string title, double durationYears, int seats)
        {
            Title = title;
            DurationYears = durationYears;
            Seats = seats;
            Subjects = new List<Subject>();
        }

        public int TotalCreditHours()
        {
            int sum = 0;
            foreach (var s in Subjects)
                sum += s.CreditHours;
            return sum;
        }

        public void ShowProgram()
        {
            Console.WriteLine($"Degree: {Title} | Duration: {DurationYears} yrs | Seats left: {Seats}");
        }
    }


    class Student
    {
        public string StudentName;
        public int Age;
        public double FSCMarks;    // out of 1100 (typical)
        public double ECATMarks;   // out of 400 (typical)
        public double Merit;       // computed
        public List<DegreeProgram> PreferenceList; // ordered preferences
        public DegreeProgram AssignedDegree;
        public List<Subject> RegisteredSubjects;

        public Student(string name, int age, double fsc, double ecat, List<DegreeProgram> prefs)
        {
            StudentName = name;
            Age = age;
            FSCMarks = fsc;
            ECATMarks = ecat;
            PreferenceList = prefs ?? new List<DegreeProgram>();
            AssignedDegree = null;
            RegisteredSubjects = new List<Subject>();
            CalculateMerit(); // fill Merit on creation
        }

        // Normalize marks and calculate merit in percentage terms (0-100)
        public void CalculateMerit()
        {
            // normalized contributions:
            // 70% weight to FSC (out of 1100), 30% weight to ECAT (out of 400)
            double fscPortion = (FSCMarks / 1100.0) * 70.0;
            double ecatPortion = (ECATMarks / 400.0) * 30.0;
            Merit = fscPortion + ecatPortion;
        }

        public int CurrentCreditHours()
        {
            int sum = 0;
            foreach (var s in RegisteredSubjects)
                sum += s.CreditHours;
            return sum;
        }

        public double CalculateFee()
        {
            double fee = 0;
            foreach (var s in RegisteredSubjects)
                fee += s.Fee;
            return fee;
        }

        public void ShowStudentShort()
        {
            string deg = AssignedDegree != null ? AssignedDegree.Title : "Not Admitted";
            Console.WriteLine($"{StudentName} | Age: {Age} | Merit: {Math.Round(Merit, 2)} | Degree: {deg}");
        }

        public void ShowStudentFull()
        {
            Console.WriteLine($"Name: {StudentName}");
            Console.WriteLine($"Age: {Age}");
            Console.WriteLine($"FSC: {FSCMarks} | ECAT: {ECATMarks} | Merit: {Math.Round(Merit, 2)}");
            Console.WriteLine($"Assigned Degree: {(AssignedDegree != null ? AssignedDegree.Title : "None")}");
            Console.WriteLine($"Registered CH: {CurrentCreditHours()}");
            Console.WriteLine($"Registered Subjects: {(RegisteredSubjects.Count == 0 ? "None" : "")}");
            foreach (var s in RegisteredSubjects)
                Console.WriteLine($"  - {s.Code} ({s.CreditHours} CH) Fee: {s.Fee}");
            Console.WriteLine($"Total Fee for Registered Subjects: {CalculateFee()}");
        }
    }


    internal class Program
    {
        static List<Student> students = new List<Student>();
        static List<DegreeProgram> degrees = new List<DegreeProgram>();

        static void Main(string[] args)
        {
            int option;
            do
            {
                Console.Clear();
                ShowMainMenu();
                int.TryParse(Console.ReadLine(), out option);

                Console.Clear();
                switch (option)
                {
                    case 1:
                        AddStudentOption();
                        break;
                    case 2:
                        AddDegreeOption();
                        break;
                    case 3:
                        GenerateMeritAndAssign();
                        break;
                    case 4:
                        ViewAllRegisteredStudents();
                        break;
                    case 5:
                        ViewStudentsByDegree();
                        break;
                    case 6:
                        RegisterSubjectsForStudent();
                        break;
                    case 7:
                        CalculateFeeForStudent();
                        break;
                    case 8:
                        Console.WriteLine("Exiting program. Goodbye!");
                        break;
                    default:
                        Console.WriteLine("Invalid option. Please choose 1-8.");
                        break;
                }

                if (option != 8)
                {
                    Console.WriteLine("\nPress Enter to continue...");
                    Console.ReadLine();
                }

            } while (option != 8);
        }

        static void ShowMainMenu()
        {
            Console.WriteLine("=== SIMPLE UAMS (Challenge #4) ===");
            Console.WriteLine("1. Add Student");
            Console.WriteLine("2. Add Degree Program");
            Console.WriteLine("3. Generate Merit List & Assign Seats");
            Console.WriteLine("4. View Registered Students");
            Console.WriteLine("5. View Students in a Degree");
            Console.WriteLine("6. Register Subjects for a Student");
            Console.WriteLine("7. Calculate Fee for a Student");
            Console.WriteLine("8. Exit");
            Console.Write("Enter choice: ");
        }

        //  Option 1 
        static void AddStudentOption()
        {
            Console.WriteLine("--- Add Student ---");
            Console.Write("Student Name: ");
            string name = Console.ReadLine();

            Console.Write("Age: ");
            int.TryParse(Console.ReadLine(), out int age);

            Console.Write("FSC Marks (out of 1100): ");
            double.TryParse(Console.ReadLine(), out double fsc);

            Console.Write("ECAT Marks (out of 400): ");
            double.TryParse(Console.ReadLine(), out double ecat);

            // Let user choose preferences from existing degree list
            List<DegreeProgram> prefs = new List<DegreeProgram>();
            if (degrees.Count == 0)
            {
                Console.WriteLine("No degrees exist yet. You can still add the student, but add degrees before generating merit.");
            }
            else
            {
                Console.Write("How many preferences do you want to enter? ");
                int.TryParse(Console.ReadLine(), out int prefCount);
                prefCount = Math.Max(0, prefCount);
                for (int i = 0; i < prefCount; i++)
                {
                    Console.WriteLine("Available Degrees:");
                    for (int j = 0; j < degrees.Count; j++)
                        Console.WriteLine($"{j + 1}. {degrees[j].Title} (Seats: {degrees[j].Seats})");

                    Console.Write($"Enter preference #{i + 1} (index number): ");
                    int.TryParse(Console.ReadLine(), out int idx);
                    if (idx >= 1 && idx <= degrees.Count)
                        prefs.Add(degrees[idx - 1]);
                    else
                        Console.WriteLine("Invalid index, preference skipped.");
                }
            }

            Student s = new Student(name, age, fsc, ecat, prefs);
            students.Add(s);
            Console.WriteLine($"Student '{name}' added. Merit: {Math.Round(s.Merit, 2)}");
        }

        //  Option 2 
        static void AddDegreeOption()
        {
            Console.WriteLine("--- Add Degree Program ---");
            Console.Write("Degree Title: ");
            string title = Console.ReadLine();

            Console.Write("Duration (years): ");
            double.TryParse(Console.ReadLine(), out double duration);

            Console.Write("Number of Seats: ");
            int.TryParse(Console.ReadLine(), out int seats);
            seats = Math.Max(0, seats);

            DegreeProgram d = new DegreeProgram(title, duration, seats);

            Console.Write("How many subjects to add? ");
            int.TryParse(Console.ReadLine(), out int n);
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine($"--- Subject #{i + 1} ---");
                Console.Write("Subject Code: ");
                string code = Console.ReadLine();
                Console.Write("Subject Type/Name: ");
                string type = Console.ReadLine();
                Console.Write("Credit Hours: ");
                int.TryParse(Console.ReadLine(), out int ch);
                Console.Write("Subject Fees: ");
                double.TryParse(Console.ReadLine(), out double fee);
                d.Subjects.Add(new Subject(code, type, ch, fee));
            }

            degrees.Add(d);
            Console.WriteLine($"Degree '{title}' added with {seats} seats.");
        }

        //  Option 3 
        static void GenerateMeritAndAssign()
        {
            Console.WriteLine("--- Generating Merit List & Assigning Seats ---");

            if (students.Count == 0)
            {
                Console.WriteLine("No students to process.");
                return;
            }
            if (degrees.Count == 0)
            {
                Console.WriteLine("No degree programs available. Add degrees first.");
                return;
            }

            // Recalculate merit in case marks changed
            foreach (var s in students)
                s.CalculateMerit();

            // Create a copy list and sort by Merit descending
            List<Student> sorted = new List<Student>(students);
            sorted.Sort((a, b) => b.Merit.CompareTo(a.Merit));

            // Reset assignments (optional: we'll reassign)
            foreach (var st in students)
                st.AssignedDegree = null;

            // Assign students by their preference list; if first pref is full, try next, etc.
            foreach (var stud in sorted)
            {
                foreach (var pref in stud.PreferenceList)
                {
                    if (pref.Seats > 0)
                    {
                        stud.AssignedDegree = pref;
                        pref.Seats -= 1;
                        break; // assigned, move to next student
                    }
                }
            }

            Console.WriteLine("Assignment completed. Summary of assignments:");
            foreach (var st in sorted)
                st.ShowStudentShort();
        }

        //  Option 4 
        static void ViewAllRegisteredStudents()
        {
            Console.WriteLine("--- View All Students (Registered & Not) ---");
            if (students.Count == 0)
            {
                Console.WriteLine("No students added yet.");
                return;
            }

            for (int i = 0; i < students.Count; i++)
            {
                Console.WriteLine($"\nStudent #{i + 1}:");
                students[i].ShowStudentFull();
            }
        }

        // Option 5 
        static void ViewStudentsByDegree()
        {
            Console.WriteLine("--- View Students by Degree ---");
            if (degrees.Count == 0)
            {
                Console.WriteLine("No degrees available.");
                return;
            }

            Console.WriteLine("Available Degrees:");
            for (int i = 0; i < degrees.Count; i++)
                Console.WriteLine($"{i + 1}. {degrees[i].Title}");

            Console.Write("Enter degree index to view: ");
            int.TryParse(Console.ReadLine(), out int sel);
            if (sel < 1 || sel > degrees.Count)
            {
                Console.WriteLine("Invalid index.");
                return;
            }

            var chosen = degrees[sel - 1];
            Console.WriteLine($"Students admitted to {chosen.Title}:");
            bool any = false;
            foreach (var st in students)
            {
                if (st.AssignedDegree == chosen)
                {
                    Console.WriteLine($" - {st.StudentName} | Merit: {Math.Round(st.Merit, 2)}");
                    any = true;
                }
            }
            if (!any) Console.WriteLine("No students admitted to this degree yet.");
        }

        //  Option 6
        static void RegisterSubjectsForStudent()
        {
            Console.WriteLine("--- Register Subjects for a Student ---");
            Console.Write("Enter student name: ");
            string name = Console.ReadLine();

            Student s = FindStudentByName(name);
            if (s == null)
            {
                Console.WriteLine("Student not found.");
                return;
            }

            if (s.AssignedDegree == null)
            {
                Console.WriteLine("Student has not been assigned a degree. Cannot register subjects.");
                return;
            }

            DegreeProgram deg = s.AssignedDegree;
            Console.WriteLine($"Registering for degree: {deg.Title}");
            if (deg.Subjects.Count == 0)
            {
                Console.WriteLine("This degree has no subjects defined.");
                return;
            }

            bool stop = false;
            while (!stop)
            {
                Console.WriteLine("\nAvailable Subjects:");
                for (int i = 0; i < deg.Subjects.Count; i++)
                {
                    Console.Write($"{i + 1}. ");
                    deg.Subjects[i].ShowSubject();
                }
                Console.WriteLine("0. Stop registering subjects");
                Console.WriteLine($"Current CH: {s.CurrentCreditHours()} / 9");

                Console.Write("Choose subject index to register: ");
                int.TryParse(Console.ReadLine(), out int idx);
                if (idx == 0)
                {
                    stop = true;
                    continue;
                }
                if (idx < 1 || idx > deg.Subjects.Count)
                {
                    Console.WriteLine("Invalid index."); continue;
                }

                Subject chosen = deg.Subjects[idx - 1];

                // Check if already registered
                bool already = false;
                foreach (var rs in s.RegisteredSubjects)
                    if (rs.Code == chosen.Code) { already = true; break; }
                if (already)
                {
                    Console.WriteLine("You already registered this subject.");
                    continue;
                }

                int newCH = s.CurrentCreditHours() + chosen.CreditHours;
                if (newCH > 9)
                {
                    Console.WriteLine("Cannot add this subject. Credit hour limit (9) exceeded.");
                    continue;
                }

                s.RegisteredSubjects.Add(chosen);
                Console.WriteLine($"Subject {chosen.Code} added. New CH total: {s.CurrentCreditHours()}");

                if (s.CurrentCreditHours() == 9)
                {
                    Console.WriteLine("You have reached the maximum allowed credit hours (9).");
                    stop = true;
                }
            }
        }

        //  Option 7 
        static void CalculateFeeForStudent()
        {
            Console.WriteLine("--- Calculate Fee for a Student ---");
            Console.Write("Enter student name: ");
            string name = Console.ReadLine();

            Student s = FindStudentByName(name);
            if (s == null)
            {
                Console.WriteLine("Student not found.");
                return;
            }

            Console.WriteLine($"Calculating fee for {s.StudentName}:");
            double fee = s.CalculateFee();
            Console.WriteLine($"Total fee for registered subjects: {fee}");
        }

        // Helpers
        static Student FindStudentByName(string name)
        {
            foreach (var st in students)
                if (st.StudentName.Equals(name, StringComparison.OrdinalIgnoreCase))
                    return st;
            return null;
        }
    }
}